package com.example.iassit.MapStuff.Navigation;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

import com.example.iassit.R;


public class EmergencyActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_emergency);
    }
}